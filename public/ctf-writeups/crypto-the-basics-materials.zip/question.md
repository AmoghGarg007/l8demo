# Crypto: The Basics

**Category**: Cryptography
**Difficulty**: Easy

## Context
An anomalous payload was identified in a recent packet capture during a routine network audit. While it appears to be secure at first glance, a brief structural analysis suggests it might simply process data in chunks of 6 bits rather than utilizing a true cipher suite. 

## Objective
Determine the original plaintext from the provided string.

**Intercepted Data**:
`TGF5ZXI4e2Jhc2U2NF9pc19ub3RfZW5jcnlwdGlvbn0=`

*(Note: The solution will translate to the standard flag format: `Layer8{...}`)*
