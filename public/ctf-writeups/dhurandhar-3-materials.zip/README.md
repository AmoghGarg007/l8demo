# 🚩 Q6: Project "Dhurandhar 3" [MEDIUM]

## Mission Briefing
The details for this operation have been secured in an external high-clearance document.

Access the mission intelligence here:
👉 **[Operation Hard Test (PDF)](https://drive.google.com/drive/folders/1lCl-EDJ5S83xXp_wRmNJnC1J8DDF_DRS?usp=drive_link)**
